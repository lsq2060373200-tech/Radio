package Plugins::CNRadio::Plugin;

# =============================================================================
#  国内电台 (CN Radio) — DAPHILE / Lyrion (Logitech) Media Server 网络电台插件
#
#  采用 Slim::Plugin::OPMLBased，feed 由本模块动态生成菜单：
#  安装后出现在 Daphile/LMS 的 Radio 菜单，按
#  “央广 / 国际台 / 直辖市 / 华北 / 东北 / 华东 / 华南 / 华中 / 西南 / 西北”
#  分类浏览，点选即可播放。
#
#  音质策略：仅收录经 curl 实际核验的官方 HLS/AAC 直播流，
#  实测码率 170–298kbps（央广 ≈200k、CRI ≈295k、省市台 ≈170–190k），
#  低码率（48k/64k/92k/96k）一律不收。码率来源见同目录 data/cnradio.opml 的
#  description 属性与配套《使用说明.md》。
#
#  地理限制：satellitepull.cnr.cn 系列（各省市台）音频分片仅中国大陆 IP 可拉取；
#  央广(ngcdn001)/CRI(sk.cri.cn) 国内外一般均可直连。
#  依赖：播放 HLS(m3u8) 流需要 Daphile 自带 ffmpeg 转码（默认开启）或 PlayHLS 插件。
# =============================================================================

use strict;
use warnings;

use base qw(Slim::Plugin::OPMLBased);

use Slim::Utils::Log;

our $VERSION = '1.0.0';

my $log = Slim::Utils::Log->addLogCategory({
    'category'     => 'plugin.cnradio',
    'defaultLevel' => 'ERROR',
});

# -----------------------------------------------------------------------------
# 电台目录：{ name => 分类名, stations => [ [台名, 直播URL, 码率kbps], ... ] }
# 数据与 chinese-radio-stations.opml 同源，102 台全部经实测核验（2026-10-10）。
# -----------------------------------------------------------------------------
my @CATS = (
    {
        name => '央广 CNR',
        stations => [
            [ '央广·中国之声（新闻）', 'http://ngcdn001.cnr.cn/live/zgzs/index.m3u8', 203 ],
            [ '央广·经济之声（财经）', 'http://ngcdn001.cnr.cn/live/jjzs/index.m3u8', 200 ],
            [ '央广·音乐之声（流行音乐）', 'http://ngcdn001.cnr.cn/live/yyzs/index.m3u8', 202 ],
            [ '央广·经典音乐广播（经典音乐）', 'http://ngcdn001.cnr.cn/live/dszs/index.m3u8', 200 ],
            [ '央广·中华之声（对台广播）', 'http://ngcdn001.cnr.cn/live/zhzs/index.m3u8', 200 ],
            [ '央广·神州之声（对台广播）', 'http://ngcdn001.cnr.cn/live/szzs/index.m3u8', 200 ],
            [ '央广·大湾区之声（港澳/湾区）', 'http://ngcdn001.cnr.cn/live/hxzs/index.m3u8', 202 ],
            [ '央广·香港之声（对港广播）', 'http://ngcdn001.cnr.cn/live/xgzs/index.m3u8', 201 ],
            [ '央广·民族之声（民族）', 'http://ngcdn001.cnr.cn/live/mzzs/index.m3u8', 200 ],
            [ '央广·文艺之声（文艺）', 'http://ngcdn001.cnr.cn/live/wyzs/index.m3u8', 200 ],
            [ '央广·老年之声（综合）', 'http://ngcdn001.cnr.cn/live/lnzs/index.m3u8', 200 ],
            [ '央广·中国乡村之声（三农）', 'http://ngcdn001.cnr.cn/live/xczs/index.m3u8', 200 ],
            [ '央广·藏语广播（民族语言）', 'http://ngcdn001.cnr.cn/live/zygb/index.m3u8', 200 ],
            [ '央广·维语广播（民族语言）', 'http://ngcdn001.cnr.cn/live/wygb/index.m3u8', 200 ],
            [ '央广·哈语广播（民族语言）', 'http://ngcdn001.cnr.cn/live/hygb/index.m3u8', 200 ],
            [ '央广·中国交通广播（交通）', 'http://ngcdn001.cnr.cn/live/gsgljtgb/index.m3u8', 200 ],
        ],
    },
    {
        name => '国际台 CRI',
        stations => [
            [ 'CRI·环球资讯广播（资讯）', 'http://sk.cri.cn/905.m3u8', 298 ],
            [ 'CRI·南海之声（综合）', 'http://sk.cri.cn/nhzs.m3u8', 295 ],
            [ 'CRI·中文环球广播（华语）', 'http://sk.cri.cn/hyhq.m3u8', 295 ],
            [ 'CRI·海峡飞虹（对台）', 'http://sk.cri.cn/hxfh.m3u8', 295 ],
            [ 'CRI·NEWS Plus AM846（英语资讯）', 'http://sk.cri.cn/am846.m3u8', 294 ],
        ],
    },
    {
        name => '北京广播',
        stations => [
            [ '北京新闻广播（新闻 FM94.5/AM828）', 'http://satellitepull.cnr.cn/live/wxbjxwgb/playlist.m3u8', 186 ],
            [ '京津冀之声（经典音乐/综合）', 'http://satellitepull.cnr.cn/live/wxbjcsfwgl/playlist.m3u8', 179 ],
        ],
    },
    {
        name => '上海广播',
        stations => [
            [ '上海新闻广播（新闻 FM93.4/AM990）', 'http://satellitepull.cnr.cn/live/wx32shrmgb/playlist.m3u8', 186 ],
            [ '上海东方广播电台（综合）', 'http://satellitepull.cnr.cn/live/wx32dfgbdt/playlist.m3u8', 178 ],
        ],
    },
    {
        name => '重庆广播',
        stations => [
            [ '重庆新闻广播（新闻）', 'http://satellitepull.cnr.cn/live/wxcqxwgb/playlist.m3u8', 184 ],
            [ '重庆音乐广播（音乐）', 'http://satellitepull.cnr.cn/live/wxcqyygb/playlist.m3u8', 178 ],
            [ '重庆都市广播（都市综合）', 'http://satellitepull.cnr.cn/live/wxcqdsgb/playlist.m3u8', 182 ],
            [ '重庆文艺广播（文艺）', 'http://satellitepull.cnr.cn/live/wxcqwygb/playlist.m3u8', 181 ],
            [ '重庆经济广播（经济）', 'http://satellitepull.cnr.cn/live/wxcqjjgb/playlist.m3u8', 182 ],
        ],
    },
    {
        name => '华北地区',
        stations => [
            [ '河北综合广播（新闻综合）', 'http://satellitepull.cnr.cn/live/wxhebzhgb/playlist.m3u8', 183 ],
            [ '河北交通广播（交通）', 'http://satellitepull.cnr.cn/live/wxhebjtgb/playlist.m3u8', 185 ],
            [ '河北音乐广播（音乐）', 'http://satellitepull.cnr.cn/live/wxhebyygb/playlist.m3u8', 178 ],
            [ '山西综合广播（新闻综合）', 'http://satellitepull.cnr.cn/live/wxssxxwgb/playlist.m3u8', 181 ],
            [ '内蒙古新闻综合广播（新闻综合）', 'http://satellitepull.cnr.cn/live/wx32nmghyzhxwgb/playlist.m3u8', 178 ],
            [ '内蒙古音乐之声（音乐）', 'http://satellitepull.cnr.cn/live/wx32nmgyygb/playlist.m3u8', 183 ],
        ],
    },
    {
        name => '东北地区',
        stations => [
            [ '辽宁综合广播（新闻综合）', 'http://satellitepull.cnr.cn/live/wxlnzhgb/playlist.m3u8', 182 ],
            [ '辽宁交通广播（交通）', 'http://satellitepull.cnr.cn/live/wxlnjtgb/playlist.m3u8', 177 ],
            [ '辽宁文艺广播（文艺）', 'http://satellitepull.cnr.cn/live/wxlnwygb/playlist.m3u8', 180 ],
            [ '吉林新闻综合广播（新闻综合）', 'http://satellitepull.cnr.cn/live/wxjlxwzhgb/playlist.m3u8', 179 ],
            [ '吉林交通广播（交通）', 'http://satellitepull.cnr.cn/live/wxjljtgb/playlist.m3u8', 187 ],
            [ '黑龙江新闻广播（新闻）', 'http://satellitepull.cnr.cn/live/wx32hljxwgb/playlist.m3u8', 186 ],
            [ '黑龙江交通广播（交通）', 'http://satellitepull.cnr.cn/live/wx32hljjtgb/playlist.m3u8', 180 ],
            [ '黑龙江音乐广播（音乐）', 'http://satellitepull.cnr.cn/live/wx32hljyygb/playlist.m3u8', 180 ],
        ],
    },
    {
        name => '华东地区',
        stations => [
            [ '江苏新闻广播（新闻）', 'http://satellitepull.cnr.cn/live/wx32jsxwgb/playlist.m3u8', 180 ],
            [ '江苏交通广播网（交通 FM101.1）', 'http://satellitepull.cnr.cn/live/wx32jsjtgb/playlist.m3u8', 174 ],
            [ '江苏经典流行音乐广播（音乐 FM97.5）', 'http://satellitepull.cnr.cn/live/wx32jsjdlxyy/playlist.m3u8', 185 ],
            [ '浙江之声（综合新闻）', 'http://satellitepull.cnr.cn/live/wxzjzs/playlist.m3u8', 179 ],
            [ '浙江交通之声（交通 FM93）', 'http://satellitepull.cnr.cn/live/wxzjjtgb/playlist.m3u8', 179 ],
            [ '动听968（音乐 FM96.8）', 'http://satellitepull.cnr.cn/live/wxzj968/playlist.m3u8', 185 ],
            [ '浙江城市之声（城市综合）', 'http://satellitepull.cnr.cn/live/wxzjcszs/playlist.m3u8', 182 ],
            [ '山东交通广播（交通）', 'http://satellitepull.cnr.cn/live/wxsdjtgb/playlist.m3u8', 176 ],
            [ '安徽综合广播（新闻综合）', 'http://satellitepull.cnr.cn/live/wxahxxgb/playlist.m3u8', 186 ],
            [ '安徽音乐广播（音乐）', 'http://satellitepull.cnr.cn/live/wxahyygb/playlist.m3u8', 182 ],
            [ '安徽交通广播（交通）', 'http://satellitepull.cnr.cn/live/wxahjtgb/playlist.m3u8', 177 ],
            [ '福建新闻广播（综合新闻）', 'http://satellitepull.cnr.cn/live/wx32fjxwgb/playlist.m3u8', 184 ],
            [ '福建都市广播（都市综合）', 'http://satellitepull.cnr.cn/live/wx32fjdndsgb/playlist.m3u8', 190 ],
            [ '江西新闻广播（新闻）', 'http://satellitepull.cnr.cn/live/wx32jiangxxwgb/playlist.m3u8', 174 ],
        ],
    },
    {
        name => '华南地区',
        stations => [
            [ '广东新闻广播（新闻）', 'http://satellitepull.cnr.cn/live/wxgdxwgb/playlist.m3u8', 186 ],
            [ '羊城交通台（交通 FM105.2）', 'http://satellitepull.cnr.cn/live/wxgdycjtt/playlist.m3u8', 186 ],
            [ '珠江经济台（经济 FM97.4）', 'http://satellitepull.cnr.cn/live/wxgdzjjjt/playlist.m3u8', 185 ],
            [ '广东音乐之声（流行音乐 FM99.3）', 'http://satellitepull.cnr.cn/live/wxgdyyzs/playlist.m3u8', 178 ],
            [ '广东文体广播（文体）', 'http://satellitepull.cnr.cn/live/wxgdwtgb/playlist.m3u8', 182 ],
            [ '广东城市之声（城市综合）', 'http://satellitepull.cnr.cn/live/wxgdcszs/playlist.m3u8', 180 ],
            [ '深圳交通广播（交通 FM106.2）', 'http://satellitepull.cnr.cn/live/wxszjjpl/playlist.m3u8', 182 ],
            [ '深圳飞扬971（音乐）', 'http://satellitepull.cnr.cn/live/wxszfy971/playlist.m3u8', 184 ],
            [ '广西交通台（交通）', 'http://satellitepull.cnr.cn/live/wx32gxjtgb/playlist.m3u8', 183 ],
            [ '广西音乐广播（音乐）', 'http://satellitepull.cnr.cn/live/wx32gxwygb/playlist.m3u8', 182 ],
            [ '广西经济广播（经济）', 'http://satellitepull.cnr.cn/live/wx32gxjjgb/playlist.m3u8', 182 ],
            [ '海南新闻广播（新闻）', 'http://satellitepull.cnr.cn/live/wxhainxwgb/playlist.m3u8', 184 ],
            [ '海南交通广播（交通）', 'http://satellitepull.cnr.cn/live/wxhainjtgb/playlist.m3u8', 183 ],
            [ '海南音乐广播（音乐）', 'http://satellitepull.cnr.cn/live/wxhainyygb/playlist.m3u8', 184 ],
        ],
    },
    {
        name => '华中地区',
        stations => [
            [ '河南新闻广播（新闻综合）', 'http://satellitepull.cnr.cn/live/wxhnxwgb/playlist.m3u8', 172 ],
            [ '湖北之声（新闻综合）', 'http://satellitepull.cnr.cn/live/wx32hubzsgb/playlist.m3u8', 183 ],
            [ '楚天交通广播（交通 FM92.7）', 'http://satellitepull.cnr.cn/live/wx32hubctjtgb/playlist.m3u8', 187 ],
            [ '湖北经典音乐广播（经典音乐 FM103.8）', 'http://satellitepull.cnr.cn/live/wx32hubyygb/playlist.m3u8', 183 ],
            [ '湖南新闻广播（新闻综合）', 'http://satellitepull.cnr.cn/live/wx32hunxwgb/playlist.m3u8', 180 ],
            [ '湖南交通广播（交通 FM91.8）', 'http://satellitepull.cnr.cn/live/wx32hunjtgb/playlist.m3u8', 185 ],
            [ '湖南音乐之声（音乐 FM89.3）', 'http://satellitepull.cnr.cn/live/wx32hunyygb/playlist.m3u8', 186 ],
            [ '湖南经济广播（经济）', 'http://satellitepull.cnr.cn/live/wx32hunjjgb/playlist.m3u8', 178 ],
        ],
    },
    {
        name => '西南地区',
        stations => [
            [ '四川综合广播（综合新闻）', 'http://satellitepull.cnr.cn/live/wxsczhgb/playlist.m3u8', 187 ],
            [ '四川交通广播（交通 FM101.7）', 'http://satellitepull.cnr.cn/live/wxscjtgb/playlist.m3u8', 183 ],
            [ '云南新闻广播（新闻）', 'http://satellitepull.cnr.cn/live/wxynxwgb/playlist.m3u8', 171 ],
            [ '云南音乐广播（音乐）', 'http://satellitepull.cnr.cn/live/wxynyygb/playlist.m3u8', 172 ],
            [ '云南交通广播（交通 FM91.8）', 'http://satellitepull.cnr.cn/live/wxynjtgb/playlist.m3u8', 170 ],
            [ '贵州综合广播（新闻综合）', 'http://satellitepull.cnr.cn/live/wx32gzwxwzhgb/playlist.m3u8', 182 ],
            [ '贵州音乐广播（音乐）', 'http://satellitepull.cnr.cn/live/wx32gzyygb/playlist.m3u8', 179 ],
            [ '贵州都市广播（都市综合）', 'http://satellitepull.cnr.cn/live/wx32gzqcgb/playlist.m3u8', 172 ],
            [ '贵州经济广播（经济）', 'http://satellitepull.cnr.cn/live/wx32gzjjgb/playlist.m3u8', 172 ],
        ],
    },
    {
        name => '西北地区',
        stations => [
            [ '陕西新闻广播（新闻 FM101.8）', 'http://satellitepull.cnr.cn/live/wxsxxxwgb/playlist.m3u8', 188 ],
            [ '陕西交通广播（交通 FM91.6）', 'http://satellitepull.cnr.cn/live/wxsxxjtgb/playlist.m3u8', 183 ],
            [ '陕西音乐广播（音乐 FM98.8）', 'http://satellitepull.cnr.cn/live/wxsxxyygb/playlist.m3u8', 182 ],
            [ '陕西经济广播（经济）', 'http://satellitepull.cnr.cn/live/wxsxxjjgb/playlist.m3u8', 190 ],
            [ '甘肃新闻综合广播（新闻综合）', 'http://satellitepull.cnr.cn/live/wxgsxwzhgb/playlist.m3u8', 171 ],
            [ '甘肃交通广播（交通）', 'http://satellitepull.cnr.cn/live/wxgsjtgb/playlist.m3u8', 174 ],
            [ '甘肃都市调频（都市综合）', 'http://satellitepull.cnr.cn/live/wxgsdstb/playlist.m3u8', 170 ],
            [ '甘肃青春调频（音乐）', 'http://satellitepull.cnr.cn/live/wxgsqcgb/playlist.m3u8', 171 ],
            [ '宁夏新闻广播（新闻综合）', 'http://satellitepull.cnr.cn/live/wxnxxwgb/playlist.m3u8', 174 ],
            [ '青海新闻综合广播（新闻综合）', 'http://satellitepull.cnr.cn/live/wx32qhwxzhgb/playlist.m3u8', 178 ],
            [ '新疆新闻广播（新闻·汉语）', 'http://satellitepull.cnr.cn/live/wxxjxwgb/playlist.m3u8', 181 ],
            [ '新疆交通广播（交通）', 'http://satellitepull.cnr.cn/live/wxxjjtgb/playlist.m3u8', 185 ],
            [ '西藏汉语广播（汉语综合）', 'http://satellitepull.cnr.cn/live/wxxzhygb/playlist.m3u8', 179 ],
        ],
    },
);

# -----------------------------------------------------------------------------
# 生命周期
# -----------------------------------------------------------------------------

sub initPlugin {
    my $class = shift;

    $class->SUPER::initPlugin(
        feed   => \&handleFeed,
        tag    => 'cnradio',
        menu   => 'radios',
        weight => 50,
    );
}

sub getDisplayName {
    return 'PLUGIN_CNRADIO_NAME';
}

# LMS 8+ 需要的版本信息
sub pluginVersion {
    return $VERSION;
}

# -----------------------------------------------------------------------------
# 顶层菜单：分类列表
# -----------------------------------------------------------------------------

sub handleFeed {
    my ( $client, $cb, $args ) = @_;

    my @items = map {
        my $cat = $_;
        {
            name => $cat->{name},
            type => 'link',
            url  => sub {
                my ( $c, $cb2, $a ) = @_;
                my @stations = map {
                    {
                        name      => $_->[0],
                        type      => 'audio',
                        url       => $_->[1],
                        bitrate   => $_->[2] || 128,
                        on_select => 'play',
                        playall   => 1,
                    }
                } @{ $cat->{stations} };
                $cb2->( { items => \@stations } );
            },
        }
    } @CATS;

    $cb->( { items => \@items } );
}

1;
